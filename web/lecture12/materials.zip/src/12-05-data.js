// style 对象语法 - data
export default {
    data() {
        return {
            activeColor: 'red',
            fontSize: 30
        }
    }
}
