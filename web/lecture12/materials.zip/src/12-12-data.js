// 复选框绑定 - data
export default {
    data() {
        return {
            isAgreed: false,
            hobbies: []
        }
    }
}
