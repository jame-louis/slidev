// 数组语法绑定 class - data
export default {
    data() {
        return {
            activeClass: 'active',
            errorClass: 'text-danger',
            isActive: true
        }
    }
}
