// style 数组语法 - data
export default {
    data() {
        return {
            baseStyles: {
                color: 'blue',
                fontSize: '16px'
            },
            overrideStyles: {
                color: 'red'  // 覆盖 baseStyles 中的 color
            }
        }
    }
}
