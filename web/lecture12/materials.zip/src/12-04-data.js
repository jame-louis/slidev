// 表单校验状态 - data 和 computed
export default {
    data() {
        return { username: '' }
    },
    computed: {
        usernameValid() {
            return this.username.length >= 3;
        }
    }
}
