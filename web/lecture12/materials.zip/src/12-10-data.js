// 主题色实时预览 - data 和 computed
export default {
    data() {
        return {
            themeColor: '#3498db'
        }
    },
    computed: {
        previewStyle() {
            return {
                backgroundColor: this.themeColor + '20',  // 20% 透明度
                borderColor: this.themeColor,
                color: this.themeColor
            };
        }
    }
}
