// 值绑定 - 对象值 - data
export default {
    data() {
        return {
            score: 10,
            selectedProduct: '',
            products: [
                { id: 1, name: 'iPhone', price: 5999 },
                { id: 2, name: 'iPad', price: 3999 }
            ]
        }
    }
}
