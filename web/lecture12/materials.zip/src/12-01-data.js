// 对象语法绑定 class - data
export default {
    data() {
        return {
            isActive: true,
            hasError: false
        }
    }
}
