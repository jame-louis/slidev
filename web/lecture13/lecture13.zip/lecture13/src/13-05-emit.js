// $emit 示例 - 子组件向父组件发送事件
app.component('ProductCard', {
    props: ['title', 'price'],
    template: `
        <div class="card">
            <h3>{{ title }}</h3>
            <p>¥{{ price }}</p>
            <button @click="addToCart">加入购物车</button>
        </div>
    `,
    methods: {
        addToCart() {
            // 触发 add-to-cart 事件，并传递商品信息
            this.$emit('add-to-cart', {
                title: this.title,
                price: this.price
            });
        }
    }
});
