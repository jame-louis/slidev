// Props 验证示例
app.component('ProductCard', {
    props: {
        title: {
            type: String,
            required: true
        },
        price: {
            type: Number,
            default: 0
        },
        tags: {
            type: Array,
            default: () => []
        }
    }
});
