// 局部注册示例 - ProductCard 组件
import ProductCard from './ProductCard.js';

createApp({
    components: {
        // 局部注册
        ProductCard
    },
    data() {
        return { products: [/* ... */] }
    },
    template: `
        <ProductCard
            v-for="item in products"
            :key="item.id"
            :product="item"
        />
    `
}).mount('#app');
