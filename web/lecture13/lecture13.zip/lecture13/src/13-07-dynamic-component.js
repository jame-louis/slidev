// 动态组件示例
const app = createApp({
    data() {
        return {
            currentTab: 'ProductList'
        }
    }
});

app.component('ProductList', {
    template: '<div><h3>商品列表</h3></div>'
});

app.component('OrderList', {
    template: '<div><h3>订单列表</h3></div>'
});

app.mount('#app');
