// 全局注册示例 - CartBadge 组件
const app = createApp({ /* ... */ });

// 全局注册 CartBadge 组件
app.component('CartBadge', {
    props: ['count'],
    template: `
        <span class="badge">
            购物车 {{ count }} 件
        </span>
    `
});

app.mount('#app');
