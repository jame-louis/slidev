// 组件中使用指令示例
app.component('SearchBox', {
    data() {
        return { keyword: '' }
    },
    template: `
        <div>
            <input v-model="keyword" v-focus placeholder="搜索...">
            <p v-if="keyword">正在搜索：{{ keyword }}</p>
        </div>
    `,
    directives: {
        focus: {
            mounted(el) { el.focus(); }
        }
    }
});
