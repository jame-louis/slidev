// 异步组件示例
const { defineAsyncComponent } = Vue;

// 方式一：基础用法
const AsyncModal = defineAsyncComponent(() =>
    import('./Modal.vue')
);

// 方式二：带加载状态
const AsyncChart = defineAsyncComponent({
    loader: () => new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                template: '<div class="chart">图表加载完成</div>'
            });
        }, 2000);
    }),
    loadingComponent: {
        template: '<div>加载中...</div>'
    },
    delay: 200
});
