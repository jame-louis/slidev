// 生命周期钩子示例
createApp({
    data() {
        return { count: 0, timer: null }
    },
    created() {
        console.log('组件已创建');
        // 可在此发起数据请求
    },
    mounted() {
        console.log('DOM 已挂载');
        // 启动定时器
        this.timer = setInterval(() => {
            this.count++;
        }, 1000);
    },
    updated() {
        console.log('数据已更新，DOM 已重新渲染');
    },
    unmounted() {
        console.log('组件即将卸载');
        // 必须清理副作用
        clearInterval(this.timer);
    }
});
