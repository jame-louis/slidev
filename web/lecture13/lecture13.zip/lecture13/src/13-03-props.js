// Props 示例 - ProductCard 组件
app.component('ProductCard', {
    // 声明接收的 props
    props: ['title', 'price', 'image'],
    template: `
        <div class="card">
            <img :src="image" :alt="title">
            <h3>{{ title }}</h3>
            <p>¥{{ price }}</p>
        </div>
    `
});
